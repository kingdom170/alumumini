"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Navbar } from "@/components/navbar"
import { alumniData, jobsData } from "@/lib/data"
import { PostJobForm, type JobFormData } from "@/components/post-job-form"
import { ResumeReviewModal, type ResumeReview } from "@/components/resume-review-modal"
import type { ResumeData } from "@/components/resume-builder-modal"

export default function AlumniDashboard() {
  const [activeTab, setActiveTab] = useState<
    "dashboard" | "queries" | "profile" | "post-jobs" | "resume-reviews" | "reviews"
  >("dashboard")
  const [showPostJobForm, setShowPostJobForm] = useState(false)
  const [showResumeReviewModal, setShowResumeReviewModal] = useState(false)
  const [selectedResume, setSelectedResume] = useState<ResumeData | null>(null)
  const [postedJobs, setPostedJobs] = useState<typeof jobsData>([
    ...jobsData.filter((job) => job.postedBy === "Priya Sharma"),
  ])
  const [submittedReviews, setSubmittedReviews] = useState<ResumeReview[]>([])
  const currentAlumni = alumniData[0] // Demo alumni

  const studentResumesForReview: ResumeData[] = [
    {
      id: "1",
      fullName: "Aditya Kumar",
      email: "aditya@email.com",
      phone: "+91-9876543210",
      summary: "Passionate software developer with 1 year of internship experience in web development",
      experience: "Frontend Developer Intern • TechCorp • 2024 • Developed React applications and fixed UI bugs",
      education: "B.Tech CSE • XYZ University • 2024",
      skills: "React, JavaScript, HTML, CSS, Node.js, MongoDB",
      certifications: "Google Cloud Associate Cloud Engineer",
      createdAt: new Date("2024-12-01"),
    },
    {
      id: "2",
      fullName: "Priya Nair",
      email: "priya@email.com",
      phone: "+91-9876543211",
      summary: "Data-driven developer interested in data science and machine learning",
      experience: "Data Science Intern • Analytics Co. • 2024 • Built predictive models using Python",
      education: "B.Tech CSE • XYZ University • 2024",
      skills: "Python, Pandas, NumPy, TensorFlow, SQL, Tableau",
      certifications: "AWS Machine Learning Specialty",
      createdAt: new Date("2024-12-05"),
    },
    {
      id: "3",
      fullName: "Rohit Gupta",
      email: "rohit@email.com",
      phone: "+91-9876543212",
      summary: "Full-stack developer with experience in building scalable web applications",
      experience: "Junior Developer • WebSolutions • 2023-2024 • Built REST APIs and frontend interfaces",
      education: "B.Tech IT • ABC University • 2023",
      skills: "JavaScript, React, Node.js, Express, PostgreSQL, Docker",
      certifications: "Full Stack Web Development Certification",
      createdAt: new Date("2024-11-15"),
    },
  ]

  const studentQueries = [
    {
      id: 1,
      studentName: "Aditya Kumar",
      question: "How to prepare for tech interviews?",
      timestamp: "2 hours ago",
    },
    {
      id: 2,
      studentName: "Priya Nair",
      question: "Career transition from core to software?",
      timestamp: "5 hours ago",
    },
    {
      id: 3,
      studentName: "Rohit Gupta",
      question: "Best practices for code optimization?",
      timestamp: "1 day ago",
    },
  ]

  const receivedReviews = [
    {
      id: "1",
      studentName: "Aditya Kumar",
      itemType: "mentorship" as const,
      rating: 5,
      comment: "Priya was incredibly helpful in preparing for my interviews. Great mentor!",
      date: "2025-01-10",
    },
    {
      id: "2",
      studentName: "Priya Nair",
      itemType: "mentorship" as const,
      rating: 4,
      comment: "Excellent guidance on career transition. Highly recommended!",
      date: "2025-01-05",
    },
    {
      id: "3",
      studentName: "Rohit Gupta",
      itemType: "mentorship" as const,
      rating: 5,
      comment: "One-on-one sessions were very productive. Learned a lot!",
      date: "2024-12-28",
    },
  ]

  const handlePostJob = (jobData: JobFormData) => {
    const newJob = {
      id: Math.max(...jobsData.map((j) => j.id), 0) + 1,
      ...jobData,
      postedBy: currentAlumni.name,
    }
    setPostedJobs([newJob, ...postedJobs])
    setShowPostJobForm(false)
  }

  const handleDeleteJob = (jobId: number) => {
    setPostedJobs(postedJobs.filter((job) => job.id !== jobId))
  }

  const handleSubmitReview = (review: ResumeReview) => {
    setSubmittedReviews([review, ...submittedReviews])
    setShowResumeReviewModal(false)
    alert("Review submitted successfully!")
  }

  const getStudentReviews = (resumeId: string) => {
    return submittedReviews.filter((r) => r.resumeId === resumeId)
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar userType="alumni" currentPage="dashboard" />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Tabs */}
        <div className="flex gap-4 mb-8 border-b border-border overflow-x-auto">
          {(["dashboard", "queries", "post-jobs", "resume-reviews", "reviews", "profile"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 font-medium text-sm border-b-2 transition-colors whitespace-nowrap ${
                activeTab === tab
                  ? "border-primary text-primary"
                  : "border-transparent text-muted-foreground hover:text-foreground"
              }`}
            >
              {tab === "post-jobs"
                ? "Post Jobs"
                : tab === "resume-reviews"
                  ? "Resume Reviews"
                  : tab === "reviews"
                    ? "Reviews Received"
                    : tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>

        {/* Dashboard Tab */}
        {activeTab === "dashboard" && (
          <div className="space-y-8">
            {/* Welcome */}
            <div className="bg-gradient-to-r from-primary/10 to-accent/10 border border-primary/20 rounded-lg p-8">
              <h1 className="text-3xl font-bold text-foreground mb-2">Welcome, {currentAlumni.name}!</h1>
              <p className="text-muted-foreground">Thank you for giving back to the alumni community</p>
            </div>

            {/* Stats */}
            <div className="grid md:grid-cols-4 gap-6">
              <div className="bg-card border border-border rounded-lg p-6">
                <div className="text-3xl font-bold text-primary mb-2">12</div>
                <p className="text-sm text-muted-foreground">Students Mentored</p>
              </div>
              <div className="bg-card border border-border rounded-lg p-6">
                <div className="text-3xl font-bold text-accent mb-2">28</div>
                <p className="text-sm text-muted-foreground">Chat Messages</p>
              </div>
              <div className="bg-card border border-border rounded-lg p-6">
                <div className="text-3xl font-bold text-primary mb-2">5</div>
                <p className="text-sm text-muted-foreground">Events Hosted</p>
              </div>
              <div className="bg-card border border-border rounded-lg p-6">
                <div className="text-3xl font-bold text-accent mb-2">{postedJobs.length}</div>
                <p className="text-sm text-muted-foreground">Jobs Posted</p>
              </div>
            </div>

            {/* Recent Activity */}
            <div>
              <h2 className="text-2xl font-bold text-foreground mb-6">Recent Student Queries</h2>
              <div className="space-y-4">
                {studentQueries.slice(0, 2).map((query) => (
                  <div
                    key={query.id}
                    className="bg-card border border-border rounded-lg p-6 hover:border-primary transition-colors"
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <h3 className="font-semibold text-foreground mb-2">{query.studentName}</h3>
                        <p className="text-muted-foreground mb-2">{query.question}</p>
                        <p className="text-xs text-muted-foreground">{query.timestamp}</p>
                      </div>
                      <Button size="sm">Respond</Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Queries Tab */}
        {activeTab === "queries" && (
          <div>
            <h2 className="text-2xl font-bold text-foreground mb-6">Student Queries</h2>
            <div className="space-y-4">
              {studentQueries.map((query) => (
                <div
                  key={query.id}
                  className="bg-card border border-border rounded-lg p-6 hover:border-primary transition-colors"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <h3 className="font-semibold text-foreground mb-2">{query.studentName}</h3>
                      <p className="text-muted-foreground mb-3">{query.question}</p>
                      <p className="text-xs text-muted-foreground mb-4">{query.timestamp}</p>
                    </div>
                    <Button size="sm">Respond via Chat</Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === "post-jobs" && (
          <div>
            <div className="flex items-center justify-between mb-8">
              <div>
                <h2 className="text-2xl font-bold text-foreground mb-2">Jobs & Internships Posted</h2>
                <p className="text-muted-foreground">Manage all the job opportunities you've posted for students</p>
              </div>
              <Button onClick={() => setShowPostJobForm(true)} className="whitespace-nowrap">
                + Post New Job
              </Button>
            </div>

            {postedJobs.length > 0 ? (
              <div className="grid md:grid-cols-2 gap-6">
                {postedJobs.map((job) => (
                  <div key={job.id} className="bg-card border border-border rounded-lg p-6 flex flex-col">
                    <div className="mb-4">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="text-xs font-bold px-2 py-1 bg-primary/10 text-primary rounded">
                          {job.type}
                        </span>
                      </div>
                      <h3 className="text-xl font-semibold text-foreground mb-2">{job.title}</h3>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                        <span className="font-medium text-accent">{job.company}</span>
                      </div>
                      <div className="text-sm text-primary font-semibold">{job.salary}</div>
                    </div>

                    <p className="text-muted-foreground mb-4 text-sm flex-1">{job.description}</p>

                    <div className="space-y-3 mb-6 text-sm">
                      <div className="flex items-start gap-2">
                        <span>📍</span>
                        <span className="text-sm text-muted-foreground">{job.location}</span>
                      </div>
                      <div>
                        <div className="text-xs font-semibold text-muted-foreground mb-1">ELIGIBILITY</div>
                        <p className="text-foreground">{job.eligibility}</p>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <Button variant="outline" className="flex-1 bg-transparent" disabled>
                        0 Applications
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => handleDeleteJob(job.id)}
                        className="text-red-600 hover:text-red-700"
                      >
                        Delete
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-card border border-border rounded-lg p-12 text-center">
                <p className="text-muted-foreground mb-4">No jobs posted yet</p>
                <Button onClick={() => setShowPostJobForm(true)}>Post Your First Job</Button>
              </div>
            )}
          </div>
        )}

        {activeTab === "resume-reviews" && (
          <div>
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-foreground mb-2">Student Resumes for Review</h2>
              <p className="text-muted-foreground">Review student resumes and provide constructive feedback</p>
            </div>

            <div className="grid gap-6">
              {studentResumesForReview.map((resume) => {
                const reviews = getStudentReviews(resume.id)
                return (
                  <div key={resume.id} className="bg-card border border-border rounded-lg p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <h3 className="text-lg font-semibold text-foreground">{resume.fullName}</h3>
                        <p className="text-sm text-muted-foreground mb-2">{resume.email}</p>
                        <p className="text-sm text-foreground mb-2">
                          <strong>Summary:</strong> {resume.summary}
                        </p>
                        <p className="text-sm text-foreground mb-2">
                          <strong>Experience:</strong> {resume.experience}
                        </p>
                        <p className="text-sm text-foreground mb-2">
                          <strong>Skills:</strong> {resume.skills}
                        </p>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-foreground mb-2">{reviews.length}</div>
                        <p className="text-xs text-muted-foreground">Reviews</p>
                      </div>
                    </div>

                    {reviews.length > 0 && (
                      <div className="bg-muted/30 rounded-lg p-4 mb-4 max-h-32 overflow-y-auto">
                        {reviews.map((review) => (
                          <div
                            key={review.id}
                            className="mb-3 last:mb-0 pb-3 last:pb-0 border-b last:border-b-0 border-border"
                          >
                            <div className="flex gap-1 mb-1">
                              {[1, 2, 3, 4, 5].map((star) => (
                                <span
                                  key={star}
                                  className={`text-sm ${star <= review.rating ? "text-yellow-400" : "text-muted-foreground"}`}
                                >
                                  ★
                                </span>
                              ))}
                            </div>
                            <p className="text-xs text-foreground">{review.feedback}</p>
                          </div>
                        ))}
                      </div>
                    )}

                    <Button
                      onClick={() => {
                        setSelectedResume(resume)
                        setShowResumeReviewModal(true)
                      }}
                    >
                      {reviews.length > 0 ? "Update Review" : "Review Resume"}
                    </Button>
                  </div>
                )
              })}
            </div>
          </div>
        )}

        {/* Reviews Tab */}
        {activeTab === "reviews" && (
          <div>
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-foreground mb-2">Reviews & Ratings</h2>
              <p className="text-muted-foreground">Feedback from students about your mentorship</p>
            </div>

            {receivedReviews.length > 0 ? (
              <div className="space-y-4">
                {receivedReviews.map((review) => (
                  <div key={review.id} className="bg-card border border-border rounded-lg p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <h3 className="font-semibold text-foreground mb-1">{review.studentName}</h3>
                        <div className="flex gap-1 mb-3">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <span
                              key={star}
                              className={`text-lg ${star <= review.rating ? "text-yellow-400" : "text-muted-foreground"}`}
                            >
                              ★
                            </span>
                          ))}
                        </div>
                      </div>
                      <p className="text-xs text-muted-foreground">{review.date}</p>
                    </div>
                    <p className="text-muted-foreground">{review.comment}</p>
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-card border border-border rounded-lg p-12 text-center">
                <p className="text-muted-foreground">No reviews yet. Keep mentoring students!</p>
              </div>
            )}
          </div>
        )}

        {/* Profile Tab */}
        {activeTab === "profile" && (
          <div className="max-w-2xl">
            <h2 className="text-2xl font-bold text-foreground mb-6">Your Profile</h2>
            <div className="bg-card border border-border rounded-lg p-8">
              <div className="text-6xl mb-6">{currentAlumni.image}</div>

              <div className="space-y-6">
                <div>
                  <label className="text-sm font-semibold text-muted-foreground">Full Name</label>
                  <p className="text-lg text-foreground mt-2">{currentAlumni.name}</p>
                </div>

                <div>
                  <label className="text-sm font-semibold text-muted-foreground">Email ID</label>
                  <p className="text-lg text-foreground mt-2">{currentAlumni.email}</p>
                </div>

                <div>
                  <label className="text-sm font-semibold text-muted-foreground">Profession</label>
                  <p className="text-lg text-foreground mt-2">{currentAlumni.profession}</p>
                </div>

                <div>
                  <label className="text-sm font-semibold text-muted-foreground">Course Completed</label>
                  <p className="text-lg text-foreground mt-2">{currentAlumni.course}</p>
                </div>

                <div>
                  <label className="text-sm font-semibold text-muted-foreground">Current Field of Work</label>
                  <p className="text-lg text-foreground mt-2">{currentAlumni.field}</p>
                </div>

                <div>
                  <label className="text-sm font-semibold text-muted-foreground">Company</label>
                  <p className="text-lg text-foreground mt-2">{currentAlumni.company}</p>
                </div>

                <div>
                  <label className="text-sm font-semibold text-muted-foreground">Batch Year</label>
                  <p className="text-lg text-foreground mt-2">{currentAlumni.batch}</p>
                </div>

                <Button className="w-full">Edit Profile</Button>
              </div>
            </div>
          </div>
        )}
      </main>

      {showPostJobForm && <PostJobForm onClose={() => setShowPostJobForm(false)} onSubmit={handlePostJob} />}

      {showResumeReviewModal && selectedResume && (
        <ResumeReviewModal
          resume={selectedResume}
          onClose={() => {
            setShowResumeReviewModal(false)
            setSelectedResume(null)
          }}
          onSubmit={handleSubmitReview}
          existingReview={submittedReviews.find((r) => r.resumeId === selectedResume.id)}
        />
      )}
    </div>
  )
}
